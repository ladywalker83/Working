class myCreds:
    hostname = 'cis3368db.c5xe233yagcc.us-east-1.rds.amazonaws.com'
    username = 'admin'
    password = 'Test#001'
    database = 'cis3368db'