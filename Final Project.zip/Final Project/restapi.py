import flask
from flask import Flask, jsonify, request

from sql import DBconnection

import mysql.connector
from mysql.connector import Error

app = Flask(__name__)

dataStore = []
def DBconnection(hostname, username, pwd, dbname):
    con = None
    try:
        con = mysql.connector.connect(
            host=hostname,
            user=username,
            password=pwd,
            database=dbname
        )
        print("Connection successful")
    except Error as e:
        print("Connection unsuccessful due to Error ", e)
    return con

mycon = DBconnection('cis3368db.c5xe233yagcc.us-east-1.rds.amazonaws.com', 'admin', 'Test#001', 'cis3368db')

@app.route('/investor', methods=['POST'])
def createInvestor():
    investor = request.json
    dataStore.append(investor)
    return jsonify(investor), 201

@app.route('/investor', methods=['GET'], endpoint='investor1')
def readinvestor1():
    return jsonify(dataStore), 200

@app.route('/investor/<int:investorid>', methods=['GET'], endpoint='investor2')
def readinvestor2(investorid):
    if 0 <= investorid < len(dataStore):
        return jsonify(dataStore[investorid]), 200
    return jsonify({'ERROR!!': 'ITEM NOT FOUND'}), 404

@app.route('/investor/<int:investorid>', methods=['PUT'])
def updatedinvestor(investorid):
    if 0 <= investorid < len(dataStore):
        dataStore[investorid] = request.json
        return jsonify(dataStore[investorid]), 200
    return jsonify({'ERROR!!!': 'ITEM NOT FOUND'}), 404

@app.route('/investor/<int:investorid>', methods=['DELETE'])
def deleteinvestor(investorid):
    if 0 <= investorid < len(dataStore):
        deleteinvestor = dataStore.pop(investorid)
        return jsonify(deleteinvestor), 200
    return jsonify({'ERROR!!!': 'ITEM NOT FOUND'}), 404
# bond
@app.route('/bond', methods=['POST'])
def createInvestor():
    bond = request.json
    dataStore.append(bond)
    return jsonify(bond), 201

@app.route('/bond', methods=['GET'], endpoint='bond1')
def readbond():
    return jsonify(dataStore), 200

@app.route('/bond/<int:bondid>', methods=['GET'], endpoint='bond2')
def readbond2(bondid):
    if 0 <= bondid < len(dataStore):
        return jsonify(dataStore[bondid]), 200
    return jsonify({'ERROR!!': 'ITEM NOT FOUND'}), 404

@app.route('/bond/<int:bondid>', methods=['PUT'])
def updatedbond(bondid):
    if 0 <= bondid < len(dataStore):
        dataStore[bondid] = request.json
        return jsonify(dataStore[bondid]), 200
    return jsonify({'ERROR!!!': 'ITEM NOT FOUND'}), 404

@app.route('/bond/<int:bondid>', methods=['DELETE'])
def deletebond(bondid):
    if 0 <= bondid < len(dataStore):
        deletedbond = dataStore.pop(bondid)
        return jsonify(deletedbond), 200
    return jsonify({'ERROR!!!': 'ITEM NOT FOUND'}), 404

# stock
@app.route('/stock', methods=['POST'])
def createstock():
    stock = request.json
    dataStore.append(stock)
    return jsonify(stock), 201

@app.route('/stock', methods=['GET'], endpoint='stock1')
def readstock1():
    return jsonify(dataStore), 200

@app.route('/stock/<int:stockid>', methods=['GET'], endpoint='stock2')
def readstock2(stockid):
    if 0 <= stockid < len(dataStore):
        return jsonify(dataStore[stockid]), 200
    return jsonify({'ERROR!!': 'ITEM NOT FOUND'}), 404

@app.route('/stock/<int:stockid>', methods=['PUT'])
def updated(stockid):
    if 0 <= stockid < len(dataStore):
        dataStore[stockid] = request.json
        return jsonify(dataStore[stockid]), 200
    return jsonify({'ERROR!!!': 'ITEM NOT FOUND'}), 404

@app.route('/stock/<int:stockid>', methods=['DELETE'])
def deletestock(stockid):
    if 0 <= stockid < len(dataStore):
        deletestock = dataStore.pop(stockid)
        return jsonify(deletestock), 200
    return jsonify({'ERROR!!!': 'ITEM NOT FOUND'}), 404

#portfolio

@app.route('/portfolio', methods=['POST'])
def createportfolio():
    portfolio = request.json
    dataStore.append(portfolio)
    return jsonify(portfolio), 201

@app.route('/portfolio', methods=['GET'], endpoint='portfolio1')
def readportfolio1():
    return jsonify(dataStore), 200

@app.route('/portfolio/<int:portfolioid>', methods=['GET'], endpoint='portfolio2')
def readportfolio2(portfolioid):
    if 0 <= portfolioid < len(dataStore):
        return jsonify(dataStore[portfolioid]), 200
    return jsonify({'ERROR!!': 'ITEM NOT FOUND'}), 404

@app.route('/portfolio/<int:portfolioid>', methods=['PUT'])
def updated(portfolioid):
    if 0 <= portfolioid < len(dataStore):
        dataStore[portfolioid] = request.json
        return jsonify(dataStore[portfolioid]), 200
    return jsonify({'ERROR!!!': 'ITEM NOT FOUND'}), 404

@app.route('/portfolio/<int:portfolioid>', methods=['DELETE'])
def deleteportfolio(portfolioid):
    if 0 <= portfolioid < len(dataStore):
        deleteportfolio = dataStore.pop(portfolioid)
        return jsonify(deleteportfolio), 200
    return jsonify({'ERROR!!!': 'ITEM NOT FOUND'}), 404

#transaction

@app.route('/transaction', methods=['POST'])
def createtransaction():
    transaction = request.json
    dataStore.append(transaction)
    return jsonify(transaction), 201

@app.route('/transaction', methods=['GET'], endpoint='transaction1')
def readtransaction():
    return jsonify(dataStore), 200

@app.route('/transaction/<int:transactionid>', methods=['GET'], endpoint='transaction2')
def readtransaction2(transactionid):
    if 0 <= transactionid < len(dataStore):
        return jsonify(dataStore[transactionid]), 200
    return jsonify({'ERROR!!': 'ITEM NOT FOUND'}), 404

@app.route('/transaction/<int:transactionid>', methods=['PUT'])
def updated(transactionid):
    if 0 <= transactionid < len(dataStore):
        dataStore[transactionid] = request.json
        return jsonify(dataStore[transactionid]), 200
    return jsonify({'ERROR!!!': 'ITEM NOT FOUND'}), 404

@app.route('/transaction/<int:transactionid>', methods=['DELETE'])
def deleteportfolio(transactionid):
    if 0 <= transactionid < len(dataStore):
        deletetransaction = dataStore.pop(transactionid)
        return jsonify(deletetransaction), 200
    return jsonify({'ERROR!!!': 'ITEM NOT FOUND'}), 404

# 
class Transaction:
    def __init__(self, investor_id, stock_id, bond_id, transaction_type, quantity):
        self.investor_id = investor_id
        self.stock_id = stock_id
        self.bond_id = bond_id
        self.transaction_type = transaction_type
        self.quantity = quantity
 
@app.route('/transactions', methods=['POST'])
def create_transaction():
    data = request.json
    transaction = Transaction(
        investor_id =data['investor_id'],
        stock_id = data.get('stock_id'),
        bond_id = data.get('bond_id'),
        transaction_type =data['transaction_type'],
        quantity =data['quantity']
    )

class Stock():
    __table__ ='stocks'
    
class Bond():
    __table__ = 'bonds'
    
@app.route('/investors/<int:id>/portfolio', methods=['GET'])
def get_portfolio(id):
    transactions = Transaction.query.filter_by(investor_id = id).all
    portfolio = {'stocks': [], 'bonds': []}
    for txn in transactions:
        if txn.stock_id:
            stock = Stock.query.get(txn.stock_id)
            portfolio['stock'].append({
                'id': stock.id,
                'name': stock.name,
                'quanity': txn.quanity
            })
        if txn.bond_id:
            bond = Bond.query.get(txn.bond_id)
            portfolio['bond'].append({
                'id': bond.id,
                'name': bond.name,
                'quanity': txn.quanity
                
            })
    return jsonify(portfolio)    




if __name__ == '__main__':
    app.run()
