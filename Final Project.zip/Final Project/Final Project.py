#Sandra Walker
#191144
# references Professor Peddojui
# W3 School
# For some reason when i update python if refused to work, I had to go to chatgpt to help get python 3.13.1500 mto work again. 
# i also use chat gpt to degug and take out the redunancy functions 


import mysql.connector
from mysql.connector import Error

def DBconnection(hostname, username, pwd, dbname):
    con = None
    try:
        con = mysql.connector.connect(
            host=hostname,
            user=username,
            password=pwd,
            database=dbname
        )
        print("Connection successful")
    except Error as e:
        print("Connection unsuccessful due to Error ", e)
    return con

mycon = DBconnection('cis3368db.c5xe233yagcc.us-east-1.rds.amazonaws.com', 'admin', 'Test#001', 'cis3368db')

sql = "select * from investor"
mycursor = mycon.cursor(dictionary=True)
mycursor.execute(sql)
investors = mycursor.fetchall()

if mycon: 
    mycursor = mycon.cursor(dictionary=True)
else:
    print('Database connection failed')
    exit()
    
    
for investor in investors:
    print(investor)

    sql = "insert into investor (id, firstname, lastname) VALUES (%s, %s, %s)"
    mycursor.execute(sql, (investor['id'], investor['firstname'], investor['lastname']))


mycon.commit()
print("New rows added to DB for investors")


sql = "select * from stock"
mycursor.execute(sql)
stock_table = mycursor.fetchall()

for stock in stock_table:
    print(stock)

    sql = "insert into stock (id, stockname, abbreviation, currentprice) VALUES (%s, %s, %s, %s)"
    mycursor.execute(sql, (stock['id'], stock['stockname'], stock['abbreviation'], stock['currentprice']))


mycon.commit()
print("New rows added to DB for stocks")


sql = "select * from bond"
mycursor.execute(sql)
bond_table = mycursor.fetchall()

for bond in bond_table:
    print(bond)

    sql = "insert into bond (id, bondname, abbreviation, currentprice) VALUES (%s, %s, %s, %s)"
    mycursor.execute(sql, (bond['id'], bond['bondname'], bond['abbreviation'], bond['currentprice']))


mycon.commit()
print("New rows added to DB for bonds")


sql = "select * from stocktransaction"
mycursor.execute(sql)
stocktransaction_table = mycursor.fetchall()

for trans in stocktransaction_table:
    print(trans)

    sql = "insert into stocktransaction (id, date, investorid, stockid, quantity) VALUES (%s, %s, %s, %s, %s)"
    mycursor.execute(sql, (trans['id'], trans['date'], trans['investorid'], trans['stockid'], trans['quantity']))


mycon.commit()
print("New rows added to DB for stock transactions")


sql = "select * from bondtransaction"
mycursor.execute(sql)
bondtransaction_table = mycursor.fetchall()

for tbond in bondtransaction_table:
    print(tbond)

    sql = "insert into investorbondtransaction (id, date, investorid, bondid, quantity) VALUES (%s, %s, %s, %s, %s)"
    mycursor.execute(sql, (tbond['id'], tbond['date'], tbond['investorid'], tbond['bondid'], tbond['quantity']))


mycon.commit()
print("New rows added to DB for bond transactions")


mycursor.close()
mycon.close()
